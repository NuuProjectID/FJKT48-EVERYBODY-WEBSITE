export default function formatName(name) {
  return name.replace("JKT48_", "");
}